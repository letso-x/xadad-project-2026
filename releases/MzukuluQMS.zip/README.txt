Mzukulu QMS - Quality Management System
=======================================

TO INSTALL
----------
1. Double-click  Install.bat
2. It copies the app into your user profile (no admin rights needed) and adds a
   Desktop and Start Menu shortcut.
3. Choose "Y" to launch, or open it later from the "Mzukulu QMS" desktop icon.

TO RUN WITHOUT INSTALLING
-------------------------
Just double-click  MzuApplication.exe  in this folder.

TO UNINSTALL
------------
Double-click  Uninstall.bat  (your saved records are kept).

SIGN IN
-------
Log in with your email and password. If two-step verification is enabled and this
machine has not been trusted recently, a 6-digit code is emailed to you.

Demo accounts (if the database is empty): admin@mzukulu.co.za / admin123

NOTES
-----
- This package includes database.config and email.config with live credentials, so
  it is intended for YOUR machine only. Do not share this folder - it contains the
  database and email secrets.
- Requires .NET Framework 4.7.2 (built into Windows 10/11).
